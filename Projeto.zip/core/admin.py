from django.contrib import admin

from core.models import Curso

# Register your models here.
admin.site.register(Curso)